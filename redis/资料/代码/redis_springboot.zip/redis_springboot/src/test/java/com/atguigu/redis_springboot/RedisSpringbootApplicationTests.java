package com.atguigu.redis_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
